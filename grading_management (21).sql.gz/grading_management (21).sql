-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2024 at 12:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_schedule`
--

CREATE TABLE `admin_schedule` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `type` enum('schedule','announcement') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_schedule`
--

INSERT INTO `admin_schedule` (`id`, `admin_id`, `title`, `description`, `start_datetime`, `end_datetime`, `type`) VALUES
(2, 10, '123', '123', '2024-08-28 16:29:00', '2024-08-28 23:29:00', 'schedule');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `created_at`) VALUES
(10, 'Testing', 'test 1', '2024-09-28 09:45:33');

-- --------------------------------------------------------

--
-- Table structure for table `encoded_learner_data`
--

CREATE TABLE `encoded_learner_data` (
  `id` int(11) NOT NULL,
  `learner_id` int(11) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `name_extension` varchar(50) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `lrn` varchar(20) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `elementary_completer` tinyint(1) DEFAULT NULL,
  `general_average` decimal(5,2) DEFAULT NULL,
  `citation` varchar(255) DEFAULT NULL,
  `elementary_school_name` varchar(255) DEFAULT NULL,
  `school_id` varchar(50) DEFAULT NULL,
  `school_address` varchar(255) DEFAULT NULL,
  `pept_passer` tinyint(1) DEFAULT NULL,
  `pept_rating` varchar(20) DEFAULT NULL,
  `als_a_e_passer` tinyint(1) DEFAULT NULL,
  `als_rating` varchar(20) DEFAULT NULL,
  `others_specify` tinyint(1) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `testing_center` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `adviser` varchar(255) DEFAULT NULL,
  `school` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `learners_name` varchar(255) DEFAULT NULL,
  `grade` varchar(10) DEFAULT NULL,
  `school_level` varchar(50) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `division` varchar(50) DEFAULT NULL,
  `school_year` int(11) DEFAULT NULL,
  `section` varchar(50) DEFAULT NULL,
  `quarter` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `datetime_added` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `learners_name`, `grade`, `school_level`, `region`, `division`, `school_year`, `section`, `quarter`, `gender`, `subject`, `datetime_added`) VALUES
(1080, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Math', '2024-10-02 18:03:25'),
(1081, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Math', '2024-10-02 18:03:25'),
(1082, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Math', '2024-10-02 18:03:25'),
(1083, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Math', '2024-10-02 18:03:25'),
(1084, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Science', '2024-10-02 18:03:25'),
(1085, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Science', '2024-10-02 18:03:25'),
(1086, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Science', '2024-10-02 18:03:25'),
(1087, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Science', '2024-10-02 18:03:25'),
(1088, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'English', '2024-10-02 18:03:25'),
(1089, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'English', '2024-10-02 18:03:25'),
(1090, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'English', '2024-10-02 18:03:25'),
(1091, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'English', '2024-10-02 18:03:25'),
(1092, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Araling Panlipunan', '2024-10-02 18:03:25'),
(1093, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Araling Panlipunan', '2024-10-02 18:03:25'),
(1094, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Araling Panlipunan', '2024-10-02 18:03:25'),
(1095, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Araling Panlipunan', '2024-10-02 18:03:25'),
(1096, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Mapeh', '2024-10-02 18:03:25'),
(1097, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Mapeh', '2024-10-02 18:03:25'),
(1098, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Mapeh', '2024-10-02 18:03:25'),
(1099, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Mapeh', '2024-10-02 18:03:25'),
(1100, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Values', '2024-10-02 18:03:25'),
(1101, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Values', '2024-10-02 18:03:25'),
(1102, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Values', '2024-10-02 18:03:25'),
(1103, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Values', '2024-10-02 18:03:25'),
(1104, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'ESP', '2024-10-02 18:03:25'),
(1105, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'ESP', '2024-10-02 18:03:25'),
(1106, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'ESP', '2024-10-02 18:03:25'),
(1107, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'ESP', '2024-10-02 18:03:25'),
(1108, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'TLE', '2024-10-02 18:03:25'),
(1109, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'TLE', '2024-10-02 18:03:25'),
(1110, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'TLE', '2024-10-02 18:03:25'),
(1111, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'TLE', '2024-10-02 18:03:25'),
(1112, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Filipino', '2024-10-02 18:03:25'),
(1113, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Filipino', '2024-10-02 18:03:25'),
(1114, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Filipino', '2024-10-02 18:03:25'),
(1115, 'Antonio Roldan Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Filipino', '2024-10-02 18:03:25'),
(1116, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Math', '2024-10-02 18:04:53'),
(1117, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Math', '2024-10-02 18:04:53'),
(1118, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Math', '2024-10-02 18:04:53'),
(1119, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Math', '2024-10-02 18:04:53'),
(1120, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Science', '2024-10-02 18:04:53'),
(1121, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Science', '2024-10-02 18:04:53'),
(1122, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Science', '2024-10-02 18:04:53'),
(1123, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Science', '2024-10-02 18:04:53'),
(1124, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'English', '2024-10-02 18:04:53'),
(1125, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'English', '2024-10-02 18:04:53'),
(1126, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'English', '2024-10-02 18:04:53'),
(1127, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'English', '2024-10-02 18:04:53'),
(1128, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Araling Panlipunan', '2024-10-02 18:04:53'),
(1129, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Araling Panlipunan', '2024-10-02 18:04:53'),
(1130, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Araling Panlipunan', '2024-10-02 18:04:53'),
(1131, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Araling Panlipunan', '2024-10-02 18:04:53'),
(1132, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Mapeh', '2024-10-02 18:04:53'),
(1133, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Mapeh', '2024-10-02 18:04:53'),
(1134, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Mapeh', '2024-10-02 18:04:53'),
(1135, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Mapeh', '2024-10-02 18:04:53'),
(1136, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Values', '2024-10-02 18:04:53'),
(1137, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Values', '2024-10-02 18:04:53'),
(1138, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Values', '2024-10-02 18:04:53'),
(1139, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Values', '2024-10-02 18:04:53'),
(1140, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'ESP', '2024-10-02 18:04:53'),
(1141, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'ESP', '2024-10-02 18:04:53'),
(1142, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'ESP', '2024-10-02 18:04:53'),
(1143, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'ESP', '2024-10-02 18:04:53'),
(1144, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'TLE', '2024-10-02 18:04:53'),
(1145, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'TLE', '2024-10-02 18:04:53'),
(1146, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'TLE', '2024-10-02 18:04:53'),
(1147, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'TLE', '2024-10-02 18:04:53'),
(1148, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Filipino', '2024-10-02 18:04:53'),
(1149, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Filipino', '2024-10-02 18:04:53'),
(1150, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Filipino', '2024-10-02 18:04:53'),
(1151, 'Jose Niño Macasero Rama', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Filipino', '2024-10-02 18:04:53'),
(1152, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Math', '2024-10-02 18:22:26'),
(1153, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Math', '2024-10-02 18:22:26'),
(1154, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Math', '2024-10-02 18:22:26'),
(1155, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Math', '2024-10-02 18:22:26'),
(1156, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Science', '2024-10-02 18:22:26'),
(1157, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Science', '2024-10-02 18:22:26'),
(1158, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Science', '2024-10-02 18:22:26'),
(1159, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Science', '2024-10-02 18:22:26'),
(1160, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'English', '2024-10-02 18:22:26'),
(1161, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'English', '2024-10-02 18:22:26'),
(1162, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'English', '2024-10-02 18:22:26'),
(1163, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'English', '2024-10-02 18:22:26'),
(1164, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Araling Panlipunan', '2024-10-02 18:22:26'),
(1165, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Araling Panlipunan', '2024-10-02 18:22:26'),
(1166, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Araling Panlipunan', '2024-10-02 18:22:26'),
(1167, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Araling Panlipunan', '2024-10-02 18:22:26'),
(1168, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Mapeh', '2024-10-02 18:22:26'),
(1169, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Mapeh', '2024-10-02 18:22:26'),
(1170, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Mapeh', '2024-10-02 18:22:26'),
(1171, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Mapeh', '2024-10-02 18:22:26'),
(1172, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Values', '2024-10-02 18:22:26'),
(1173, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Values', '2024-10-02 18:22:26'),
(1174, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Values', '2024-10-02 18:22:26'),
(1175, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Values', '2024-10-02 18:22:26'),
(1176, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'ESP', '2024-10-02 18:22:26'),
(1177, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'ESP', '2024-10-02 18:22:26'),
(1178, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'ESP', '2024-10-02 18:22:26'),
(1179, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'ESP', '2024-10-02 18:22:26'),
(1180, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'TLE', '2024-10-02 18:22:26'),
(1181, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'TLE', '2024-10-02 18:22:26'),
(1182, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'TLE', '2024-10-02 18:22:26'),
(1183, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'TLE', '2024-10-02 18:22:26'),
(1184, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Filipino', '2024-10-02 18:22:26'),
(1185, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Filipino', '2024-10-02 18:22:26'),
(1186, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Filipino', '2024-10-02 18:22:26'),
(1187, 'test test test', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Filipino', '2024-10-02 18:22:26'),
(1188, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Math', '2024-10-02 18:25:03'),
(1189, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Math', '2024-10-02 18:25:03'),
(1190, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Math', '2024-10-02 18:25:03'),
(1191, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Math', '2024-10-02 18:25:03'),
(1192, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Science', '2024-10-02 18:25:03'),
(1193, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Science', '2024-10-02 18:25:03'),
(1194, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Science', '2024-10-02 18:25:03'),
(1195, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Science', '2024-10-02 18:25:03'),
(1196, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'English', '2024-10-02 18:25:03'),
(1197, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'English', '2024-10-02 18:25:03'),
(1198, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'English', '2024-10-02 18:25:03'),
(1199, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'English', '2024-10-02 18:25:03'),
(1200, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Araling Panlipunan', '2024-10-02 18:25:03'),
(1201, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Araling Panlipunan', '2024-10-02 18:25:03'),
(1202, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Araling Panlipunan', '2024-10-02 18:25:03'),
(1203, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Araling Panlipunan', '2024-10-02 18:25:03'),
(1204, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Mapeh', '2024-10-02 18:25:03'),
(1205, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Mapeh', '2024-10-02 18:25:03'),
(1206, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Mapeh', '2024-10-02 18:25:03'),
(1207, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Mapeh', '2024-10-02 18:25:03'),
(1208, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Values', '2024-10-02 18:25:03'),
(1209, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Values', '2024-10-02 18:25:03'),
(1210, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Values', '2024-10-02 18:25:03'),
(1211, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Values', '2024-10-02 18:25:03'),
(1212, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'ESP', '2024-10-02 18:25:03'),
(1213, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'ESP', '2024-10-02 18:25:03'),
(1214, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'ESP', '2024-10-02 18:25:03'),
(1215, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'ESP', '2024-10-02 18:25:03'),
(1216, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'TLE', '2024-10-02 18:25:03'),
(1217, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'TLE', '2024-10-02 18:25:03'),
(1218, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'TLE', '2024-10-02 18:25:03'),
(1219, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'TLE', '2024-10-02 18:25:03'),
(1220, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 1, 'Male', 'Filipino', '2024-10-02 18:25:03'),
(1221, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 2, 'Male', 'Filipino', '2024-10-02 18:25:03'),
(1222, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 3, 'Male', 'Filipino', '2024-10-02 18:25:03'),
(1223, 'test test test', '9th', 'JHS', 'VII', 'CEBU', 2027, 'Section A', 4, 'Male', 'Filipino', '2024-10-02 18:25:03'),
(1224, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Math', '2024-10-02 18:26:06'),
(1225, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Math', '2024-10-02 18:26:06'),
(1226, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Math', '2024-10-02 18:26:06'),
(1227, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Math', '2024-10-02 18:26:06'),
(1228, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Science', '2024-10-02 18:26:06'),
(1229, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Science', '2024-10-02 18:26:06'),
(1230, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Science', '2024-10-02 18:26:06'),
(1231, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Science', '2024-10-02 18:26:06'),
(1232, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'English', '2024-10-02 18:26:06'),
(1233, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'English', '2024-10-02 18:26:06'),
(1234, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'English', '2024-10-02 18:26:06'),
(1235, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'English', '2024-10-02 18:26:06'),
(1236, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Araling Panlipunan', '2024-10-02 18:26:06'),
(1237, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Araling Panlipunan', '2024-10-02 18:26:06'),
(1238, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Araling Panlipunan', '2024-10-02 18:26:06'),
(1239, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Araling Panlipunan', '2024-10-02 18:26:06'),
(1240, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Mapeh', '2024-10-02 18:26:06'),
(1241, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Mapeh', '2024-10-02 18:26:06'),
(1242, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Mapeh', '2024-10-02 18:26:06'),
(1243, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Mapeh', '2024-10-02 18:26:06'),
(1244, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Values', '2024-10-02 18:26:06'),
(1245, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Values', '2024-10-02 18:26:06'),
(1246, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Values', '2024-10-02 18:26:06'),
(1247, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Values', '2024-10-02 18:26:06'),
(1248, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'ESP', '2024-10-02 18:26:06'),
(1249, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'ESP', '2024-10-02 18:26:06'),
(1250, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'ESP', '2024-10-02 18:26:06'),
(1251, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'ESP', '2024-10-02 18:26:06'),
(1252, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'TLE', '2024-10-02 18:26:06'),
(1253, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'TLE', '2024-10-02 18:26:06'),
(1254, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'TLE', '2024-10-02 18:26:06'),
(1255, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'TLE', '2024-10-02 18:26:06'),
(1256, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 1, 'Male', 'Filipino', '2024-10-02 18:26:06'),
(1257, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 2, 'Male', 'Filipino', '2024-10-02 18:26:06'),
(1258, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 3, 'Male', 'Filipino', '2024-10-02 18:26:06'),
(1259, 'test test test admin', '7th', 'JHS', 'VII', 'CEBU', 2024, 'Section A', 4, 'Male', 'Filipino', '2024-10-02 18:26:06');

-- --------------------------------------------------------

--
-- Table structure for table `fileserver_files`
--

CREATE TABLE `fileserver_files` (
  `file_id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fileserver_files`
--

INSERT INTO `fileserver_files` (`file_id`, `folder_id`, `file_name`, `file_path`, `uploaded_at`) VALUES
(10, 14, 'grading_management (10).sql.gz', 'uploads/grading_management (10).sql.gz', '2024-09-14 14:18:25');

-- --------------------------------------------------------

--
-- Table structure for table `fileserver_folders`
--

CREATE TABLE `fileserver_folders` (
  `folder_id` int(11) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `folder_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fileserver_folders`
--

INSERT INTO `fileserver_folders` (`folder_id`, `folder_name`, `folder_password`) VALUES
(14, 'Test', '$2y$10$Rcb65WF9DtG0jhROHuwv/e2Hc8vK.mgoD8uIp872vsykpO3o0cvHq');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `alert_sent` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `teacher_id`, `title`, `description`, `start_time`, `end_time`, `alert_sent`) VALUES
(1, 4, 'Orientation', 'Teachers meeting', '2024-08-01 17:58:00', '2024-08-01 18:00:00', 0),
(2, 6, 'wdasdasdsasdasdas', 'asdasd', '2024-08-09 19:28:00', '2024-08-01 07:33:00', 0),
(5, 35, 'Science ', 'Class', '2024-08-22 09:00:00', '2024-08-22 10:00:00', 0),
(10, 10, 'Test', '1', '2024-08-25 13:49:00', '2024-08-25 20:50:00', 0),
(11, 12, '123', '123', '2024-08-07 15:58:00', '2024-08-28 21:58:00', 0),
(12, 12, '123', '123', '2024-08-28 15:59:00', '2024-08-28 15:04:00', 0),
(13, 12, '123', '123', '2024-08-28 16:02:00', '2024-09-05 16:02:00', 0),
(14, 12, '123', '123', '2024-08-28 16:04:00', '2024-08-28 16:04:00', 0),
(15, 93, 'Dance workout school competition', 'Friday', '2024-08-28 13:13:00', '2024-08-28 17:14:00', 0),
(16, 94, 'asd', 'asd', '2024-08-29 19:25:00', '2024-08-29 19:25:00', 0),
(17, 104, '123', '123', '2024-10-05 13:09:00', '2024-09-12 23:09:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `security_questions`
--

CREATE TABLE `security_questions` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `security_questions`
--

INSERT INTO `security_questions` (`id`, `question`) VALUES
(3, 'What is the name of your favorite hobby?'),
(9, 'What is the name of your favorite music artist?'),
(6, 'What is the name of your favorite vacation spot?'),
(10, 'What is your favorite animal?'),
(2, 'What is your favorite book?'),
(1, 'What is your favorite color?'),
(4, 'What is your favorite food?'),
(5, 'What is your favorite movie?'),
(7, 'What is your favorite sport?'),
(8, 'What was your favorite subject in school?');

-- --------------------------------------------------------

--
-- Table structure for table `sf2_attendance_report`
--

CREATE TABLE `sf2_attendance_report` (
  `form2Id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `learnerAttendanceConversionTool` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `quarter` varchar(10) DEFAULT NULL,
  `month` varchar(20) NOT NULL,
  `day_01` char(1) DEFAULT NULL,
  `day_02` char(1) DEFAULT NULL,
  `day_03` char(1) DEFAULT NULL,
  `day_04` char(1) DEFAULT NULL,
  `day_05` char(1) DEFAULT NULL,
  `day_06` char(1) DEFAULT NULL,
  `day_07` char(1) DEFAULT NULL,
  `day_08` char(1) DEFAULT NULL,
  `day_09` char(1) DEFAULT NULL,
  `day_10` char(1) DEFAULT NULL,
  `day_11` char(1) DEFAULT NULL,
  `day_12` char(1) DEFAULT NULL,
  `day_13` char(1) DEFAULT NULL,
  `day_14` char(1) DEFAULT NULL,
  `day_15` char(1) DEFAULT NULL,
  `day_16` char(1) DEFAULT NULL,
  `day_17` char(1) DEFAULT NULL,
  `day_18` char(1) DEFAULT NULL,
  `day_19` char(1) DEFAULT NULL,
  `day_20` char(1) DEFAULT NULL,
  `day_21` char(1) DEFAULT NULL,
  `day_22` char(1) DEFAULT NULL,
  `day_23` char(1) DEFAULT NULL,
  `day_24` char(1) DEFAULT NULL,
  `day_25` char(1) DEFAULT NULL,
  `day_26` char(1) DEFAULT NULL,
  `day_27` char(1) DEFAULT NULL,
  `day_28` char(1) DEFAULT NULL,
  `day_29` char(1) DEFAULT NULL,
  `day_30` char(1) DEFAULT NULL,
  `day_31` char(1) DEFAULT NULL,
  `total_present` int(11) DEFAULT NULL,
  `total_absent` int(11) DEFAULT NULL,
  `total_late` int(11) DEFAULT NULL,
  `total_excused` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `learners_name` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `division` varchar(100) DEFAULT NULL,
  `school_id` varchar(100) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `section` varchar(36) NOT NULL,
  `grade` varchar(36) NOT NULL,
  `school_level` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quarter` int(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `learners_name`, `region`, `division`, `school_id`, `school_year`, `gender`, `subject`, `section`, `grade`, `school_level`, `user_id`, `quarter`) VALUES
(7, 'Antonio Roldan Rama', 'VII', 'CEBU', '204726', '2024-2025', 'Male', 'All', 'Section A', '7th', 'JHS', 0, 0),
(8, 'Jose Niño Macasero Rama', 'VII', 'CEBU', '202633', '2024-2025', 'Male', 'All', 'Section A', '7th', 'JHS', 0, 0),
(9, 'test test test', 'VII', 'CEBU', '202704', '2024-2025', 'Male', 'All', 'Section A', '7th', 'JHS', 0, 0),
(10, 'test test test', 'VII', 'CEBU', '209599', '2027-2028', 'Male', 'All', 'Section A', '9th', 'JHS', 0, 0),
(11, 'test test test admin', 'VII', 'CEBU', '206491', '2024-2025', 'Male', 'All', 'Section A', '7th', 'JHS', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `written_exam` float DEFAULT NULL,
  `performance_task` float DEFAULT NULL,
  `quarterly_exam` float DEFAULT NULL,
  `final_grade` float DEFAULT NULL,
  `highest_possible_score` decimal(5,2) DEFAULT NULL,
  `lowest_score` decimal(5,2) DEFAULT NULL,
  `average_mean` decimal(5,2) DEFAULT NULL,
  `mps` decimal(5,2) DEFAULT NULL,
  `students_75_percent` int(11) DEFAULT NULL,
  `percentage_75_percent` decimal(5,2) DEFAULT NULL,
  `quarter` tinyint(4) NOT NULL,
  `academic_year` varchar(20) DEFAULT NULL,
  `4th_quarter` decimal(5,2) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `quiz1` int(11) DEFAULT 0,
  `quiz2` int(11) DEFAULT 0,
  `quiz3` int(11) DEFAULT 0,
  `quiz4` int(11) DEFAULT 0,
  `quiz5` int(11) DEFAULT 0,
  `quiz6` int(11) DEFAULT 0,
  `quiz7` int(11) DEFAULT 0,
  `quiz8` int(11) DEFAULT 0,
  `quiz9` int(11) DEFAULT 0,
  `quiz10` int(11) DEFAULT 0,
  `written_scores_total` int(11) DEFAULT 0,
  `act1` int(11) DEFAULT 0,
  `act2` int(11) DEFAULT 0,
  `act3` int(11) DEFAULT 0,
  `act4` int(11) DEFAULT 0,
  `act5` int(11) DEFAULT 0,
  `act6` int(11) DEFAULT 0,
  `act7` int(11) DEFAULT 0,
  `act8` int(11) DEFAULT 0,
  `act9` int(11) DEFAULT 0,
  `act10` int(11) DEFAULT 0,
  `performance_task_total` int(11) DEFAULT 0,
  `date_time` datetime DEFAULT current_timestamp(),
  `transmuted_grade` float DEFAULT NULL,
  `highest_written_exam_score` decimal(5,2) DEFAULT NULL,
  `highest_performance_task_score` decimal(5,2) DEFAULT NULL,
  `highest_quarterly_exam_score` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `description`, `student_id`) VALUES
(1, 'Math', 'Math course description', NULL),
(2, 'English', 'English course description', NULL),
(3, 'Science', NULL, NULL),
(5, 'Filipino', NULL, NULL),
(6, 'TLE', NULL, NULL),
(7, 'Mapeh', NULL, NULL),
(8, 'Araling Panlipunan', NULL, NULL),
(9, 'ESP', NULL, NULL),
(10, 'Values', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_assignments`
--

CREATE TABLE `teacher_assignments` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `username` varchar(36) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address` varchar(36) NOT NULL,
  `role` varchar(36) NOT NULL,
  `security_question` int(11) DEFAULT NULL,
  `security_answer` varchar(255) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `confirm_password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `security_question_id` int(11) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `failed_attempts` int(11) DEFAULT 0,
  `last_attempt_time` timestamp NULL DEFAULT NULL,
  `is_locked` tinyint(1) DEFAULT 0,
  `otp_code` varchar(6) DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `otp_verified` tinyint(1) DEFAULT 0,
  `two_factor_enabled` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `username`, `password`, `address`, `role`, `security_question`, `security_answer`, `gender`, `contact_number`, `email`, `confirm_password`, `status`, `reset_token_hash`, `reset_token_expires_at`, `security_question_id`, `hashed_password`, `failed_attempts`, `last_attempt_time`, `is_locked`, `otp_code`, `otp_expires_at`, `otp_verified`, `two_factor_enabled`) VALUES
(8, 'moses', 'moses123', '123456789', 'moses@gmail.com', 'user', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(10, 'Anna', 'Anna', 'summer', 'Anna@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(11, 'Els', 'els', 'snowqueen', 'els@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(12, 'Jose', 'JN', '123', 'Jose@gmail.com', 'Admin', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(14, 'Jake Serotonin', 'jake', '123', 'jakeS@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(23, 'Kristine', 'Kristine', '123', 'Kristine@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(31, 'Faith', 'Fathima123', 'fathima123', 'Fathima@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', 'fathima123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(35, 'Moses Mae', 'mmae.123', 'moses@123', 'moses@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', 'moses@123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(36, 'Melvic', 'Melvicgreg123', 'melvicgregg123', 'melvicgregg@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', 'melvicgregg123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(38, 'Joanna', 'JoannaMary123', '$2y$10$5cgduyhT.KukV7ZaI2sqt.sz6FWoK', 'Joannababy@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', 'Maryjoana123', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(39, 'Testing', 'testing12345', 'db7f58f20646ac82', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(40, 'Testing', 'testing12345', '$2y$10$z1xcuhBrXRoQnWuIqQnRReeGIw3n2', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(41, 'Testing', 'testing123', '$2y$10$xG6pU5X.YcwRR3ZBP7WKbON2VDi54', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(42, 'Hope', 'Hope123', '93429c1de7d67c2a', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(43, 'Hope', 'Hope123', '592ce79a93a91444', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(44, 'Hope', 'hope123', 'ddcbe7df437d9d52', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(46, 'Hope', 'Hope123', '90bd3b8491ec233a', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(47, 'Hope', 'Hope123', '0a5a7e5c095f9991', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(48, 'Hope', 'Hope123', 'db37352e501b087f', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(51, 'Joanna', 'joannabel', 'joannabel123', 'Joanna@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(53, 'Kid', 'Akidz123', '855361bf75b81bd4', 'Akid@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(58, 'Joel Caesar', 'Joel123', '4d4d554ac37e21cb', 'JoelC@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(59, 'Joel Caesar', 'Joel1234', '76fd7b01b8b833be', 'JoelC@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(61, 'Montana', 'montana123', '86dd09ece0e9bdb7', 'montana@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(65, 'Montana', 'montana123', '6ab10a4117e7f093', 'montana@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(66, 'Pleasework', 'pleasework123', '173861b3af42cc95', 'pleasework@work', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(68, 'Fathima', 'Fathima123', '$2y$10$97DydBvZK1UtABb9gvoaneGdZF2a/', 'fathima@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(69, 'Kratos', 'kratos123', '6f2d01b3323cfce3', 'kratos@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(73, 'PeterLang', 'Peter123', 'petero', 'Peterlang@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(74, 'Test90', 'Test90', 'test', 'test90@g', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(75, 'TestFunction', 'TestF', 'a109feafc575157e', 'Testf@g', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(77, 'Tester', 'Tester', 'b0177c1643372daa', 'T@g', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(78, 'Larabel', 'larabel123', 'larabel123', 'larabel@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(79, 'Xamp', 'Xamp123', 'xamp123', 'xamp@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(80, 'Testing123', 'testing123', 'testing123', 'test@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(81, 'testing123', 'testing123', '288ddc136c23509c', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(82, 'larabel123', 'larabel123', 'f6639d5901b15e8e', 'testlara@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(83, 'testing', 'testing981', '569f771afba64990', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(84, 'testing', 'testing981', '26faab65e4b125e8', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(86, 'hopeless', 'hopeless123', '27e87039533abf0f', 'hope@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(87, 'Kyler', 'kyler123', '$2y$10$mFV9PrwbJnSdVS/Wx6hduuZgnfoVX', 'kyler@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(88, 'John', 'john123', '$2y$10$6III4ynfjhWatDEqyvqV.O7ltFyl3', 'john@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(91, 'Darla', 'Darla123', 'darla123', 'darla@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(92, '123', '123123123', '123', '123@123', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(93, 'Mikaela', 'Mikaela123', 'mikaela', 'mikaela@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(94, 'Mosesmaedegoma', 'Mosesmaedegoma123', 'moses', 'Mosesmaedegoma@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(95, 'Charlie tango', 'charlie', '1', 'charlietango@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(96, 'Jolly', 'Jolly123', '12345678', 'Jolly@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(99, 'Testing', 'Testing123', 'Bradix123', 'Test@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(100, 'Jamela', 'jamela123', 'jamela123', 'jamela@gmail.com', 'Teacher', NULL, NULL, NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(101, 'Joanna Marie Hope', 'joannamarie123', 'joannamarie123', 'JoannaMarieHope@gmail.com', 'Teacher', NULL, '$2y$10$.pGqFvuQ5pVEy4n.g8qC..blQFZCxzAAo0Xniaz2RcG9SgNNfUDQi', NULL, NULL, '', '', '', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(102, 'SampleMan123', 'sampleman123', '$2y$10$sP5eXi2jJMBXXV68lejLcey7Vuxoi', 'Sampleman123@gmail.com', 'Teacher', NULL, '$2y$10$Rzv8Pz6b93OBWC/rvZRRSu6D.EqajjpmcsUvSzSl6xyRgf3hi.j/q', NULL, NULL, '', '', '', NULL, NULL, 9, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(103, 'Jocelyn Flores Mera', 'jocelyn123', 'jocelynflores123', 'JocelynFlores@gmail.com', 'Teacher', NULL, '$2y$10$mQhojuINce4QFZL2uKVDNe7fTKtcYR5fEy1aP2fSAxIIi0VsgoHAS', NULL, NULL, '', '', '', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(104, 'Lucky Chloe', 'luckychloe123', 'luckychloe123', 'LuckyChloe123@gmail.com', 'Teacher', NULL, '$2y$10$tZhn6VdGFg22cYK2xKy2CeVX7S2YonnqwII2XVLZNCFwZ5CJIWvpq', NULL, NULL, '', '', '', NULL, NULL, 3, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(105, 'Bravado Charlie', 'BravadoCharlie123', 'josenino123', 'bravadocharlie@gmail.com', 'Teacher', NULL, '$2y$10$a887x9F508jSnf0axAkmrOwpNhUuM1wrGKfgHxJq/N20Kehv1Wn4e', NULL, NULL, '', '', '', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(106, 'Joanna Marie Delos Reyes', 'JoannaMarie123', 'f3681342e57bdaca', 'JoannaMarieDelosReyes@gmail.com', 'Teacher', NULL, '$2y$10$WYzY2JckMJGIXn4Mfre0buAQH8kvN2L6ahUUD74ejwX/tDZCrMEdy', NULL, NULL, '', '', 'approved', NULL, NULL, 4, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(107, 'Samplepassword', 'Samplepassword123', '50a633c729bad457', 'samplepassword@gmail.com', 'Teacher', NULL, '$2y$10$jAX92iD1igAHfSnSd4j10efUnczCFi4maqecZPFR6KC4U0Rzxe8LS', NULL, NULL, '', '', 'approved', NULL, NULL, 2, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(108, 'Samplepassword', 'Samplepassword123', 'password123', 'samplepassword@gmail.com', 'Teacher', NULL, '$2y$10$BSbOnemjpZ0PExjt8AwrGOi/vpjF8JOb3XBpVylY8ZlXu8KWDpAXy', NULL, NULL, '', '', '', NULL, NULL, 2, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(109, 'MariaTesting', 'mariatest123', 'mariatest123', 'Mariatest@gmail.com', 'Teacher', NULL, '$2y$10$yZ7ktUS/Mst02vtWhsaEnuSi48vD3FPoYi6L8bRxNKwQBfuXPdDey', NULL, NULL, '', '', '', NULL, NULL, 7, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(110, 'TentacionMores', 'Mores123', '123', 'Mores@gmail.com', 'Teacher', NULL, '$2y$10$lGBKT/OMK7Cap0TVLMwa.eUcoJD4pwDBXHYTAI90p23lE.qCXoYs.', NULL, NULL, '', '', '', NULL, NULL, 1, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(112, 'Gradwaiting', 'gradwaiting123', '$2y$10$mph.qtUJyHB7SbvSTG3vluZbnJ/lzWReulOMeS27O9a2jQ0HIC4Jq', 'gradwaiting@gmail.com', 'Teacher', NULL, '$2y$10$V.0oyYTFfHTpFUWiPrSuN.3O2czwqjQzJA5zM2sM1lAJ203ONGWHy', NULL, NULL, '', '', '', NULL, NULL, 3, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(113, 'Failureonceagain', 'failure123', '$2y$10$TR/63uToCSQp3PC5aJvYB.Z6nvHfeW7QG5PBQFcH/6pYdQ38HjXbi', 'failure@gmail.com', 'Teacher', NULL, '$2y$10$qtREOD.ad2LgtGSo1.Zay.A6.ZRYscx11zdbLPBaF1gtaq7Q2lOhO', NULL, NULL, '', '', '', NULL, NULL, 9, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(114, 'Failuretwo', 'Failed123', '$2y$10$Pf5EFNBoL2Sav1UI1.c1z.IXPv9gA7/YUIOrtSEb4L/ojCoSMQYR.', 'failuretwo@gmail.com', 'Teacher', NULL, '$2y$10$stOXCjtn5HihIKJNbgMKd.M5t5VYLtw73scE7RNUAM.jJ2FwsBscC', NULL, NULL, '', '', '', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(115, 'ArHopeless', 'Hope123', '$2y$10$0b8eHaDk0w8MWbSnzchZ3eWV98Qo50Yz7KPczo2eGSNnO3j961n6i', 'hopeless@gmail.com', 'Teacher', NULL, '$2y$10$/Kv2UzSXIwS1VdWI1UzsqOWW8dDk6V/oq7TH5SUZfk8T0dOlD.tz.', NULL, NULL, '', '', '', NULL, NULL, 9, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(116, 'ASDASDASD', 'asdasd123', '$2y$10$iGrDA/fgTR/SDll29yCk.u6Sv57NBj6O9IcecvioWBr2Wl6E/84De', 'ASD@gmail.com', 'Teacher', NULL, '$2y$10$3nE3R2toaWMifVhQ6RiLG.iP1VVdBzngEhwQvYk.mh3cUoWW9Jp2G', NULL, NULL, '', '', '', NULL, NULL, 9, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(117, 'qweqwe123', 'qweqwe123', '$2y$10$m9W3B6cCbNj7yo3LID8YxeMciJXo0v53pyYJeAb70B/6vdTrEnxYe', 'qweqwe@gmail.com', 'Teacher', NULL, '$2y$10$Ve3Fhg8ui40Sfpgc02K1rezgloaDH4x9cdtquhL2F4GSvEbuIE3WC', NULL, NULL, '', '', '', NULL, NULL, 9, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(118, 'MosesMaeDegoma', 'Mosesmae123', 'fa8b65daee49886f', 'MosesMae@gmail.com', 'Teacher', NULL, '$2y$10$ZXDXT91hQol2cPF3eFWSk.yxYqx8KaM6i01Y.j1sZ/l2BW34v2746', NULL, NULL, '', '', 'approved', NULL, NULL, 1, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(119, 'MosesMaeDegoma', 'Mosesmae123', '$2y$10$V.ewjNE9qMT0ZbHRBchorukR3JtP2iV9iiS6CFKZAwp611RHZBqcC', 'MosesMae@gmail.com', 'Teacher', NULL, '$2y$10$lV9vD6ieai5uOxMQdOTfMu1LaWP0c/UBM2zY.oPFPAbHCuQWYFJnu', NULL, NULL, '', '', '', NULL, NULL, 1, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(120, 'Trialerror', 'Trialerror123', '8a37ffb48c2b665d', 'trialerror@gmail.com', 'Teacher', 9, '$2y$10$gDAgudL2THA7oVndx2MFuuhQ3N5HDkOB6TAsjY8Ga1QlRXzbQ8xGm', NULL, NULL, '', '', 'approved', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(121, 'Trialerror', 'Trialerror123', '$2y$10$3SDdKptqkQQrp6p7Oe7fzOddhHXC/V/t1RXdKYzeiqwh1JK4nt60S', 'trialerror@gmail.com', 'Teacher', 10, '$2y$10$OyCdyXpIqY9rDaNn2xo5suof6Go83DA6TZMy4BHgF4fB./AEvLs6S', NULL, NULL, '', '', '', NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(124, 'Trialindo', 'securityquestion123', '123456789', 'securityquestion@gmail.com', 'Teacher', NULL, '$2y$10$4s4gDLet9jVQu6zZwI8JoOKVz8v3IUbjFMLHOdIJ.WLHUuD29ta96', NULL, NULL, '', '', '', NULL, NULL, 3, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(125, 'MosesExample', 'Mmexample123', '1d5d35849eba15c6', 'Examplemoses123@gmail.com', 'Teacher', NULL, '$2y$10$FYd6WV5pM7/PaAQOMJytIulCmk5E3dIX1xul7IA/7k0QqoA7.S75.', NULL, NULL, '', '', 'approved', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(126, 'MosesExample', 'Mmexample123', 'a5ee1e6ff2c88687', 'Examplemoses123@gmail.com', 'Teacher', NULL, '$2y$10$jVJBSyn3FSnxdl8DWXgiTujYLtpoP5U5FX31Jl/Q6B8sRSzWNF46O', NULL, NULL, '', '', 'pending', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(127, 'Examplemoses321', 'moses123', '123456789', 'Example123@gmail.com', 'Teacher', NULL, '$2y$10$gRoOD5m3Y6lPMxKYWAXD7O/hrwvPKxvvOB8MH0tCOSlkxROfSAcki', NULL, NULL, '', '', '', NULL, NULL, 1, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(128, 'Teachertest', 'teachertest123', 'cd2310bc496e71b7', 'teachertest@gmail.com', 'Teacher', NULL, '$2y$10$5TkQE3ol.kNi5n.uiSwcUOpEY/J38XRc55Tp9/.Yz3bwPFDZeqc8C', NULL, NULL, '', '', 'approved', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(129, 'Teachertest', 'teachertest123', '$2y$10$qc7kUH4umt51QGWDk.Qkgeu5dV8vA1/MYnXQSJGnEkiGM8pvv4WIG', 'teachertest@gmail.com', 'Teacher', NULL, '$2y$10$isLb1NQOOOHK.NC8G4GjYeE9JxBLPYPquDBfhIc7rnL7ff0jz1SV.', NULL, NULL, '', '', '', NULL, NULL, 10, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(130, 'HopeFaith', 'Hopefaith123', 'hopefaith123', 'Hopefaith@gmail.com', 'Teacher', NULL, '$2y$10$bzq3UhxYXV4gDUd6V.p7GuRGF2Mzm9gW2oLMk3INkcIG1vAb3xOz.', NULL, NULL, '', '', '', NULL, NULL, 1, NULL, 0, NULL, 0, NULL, NULL, 0, 0),
(131, 'MarieRoseGaribas', 'MarieRose123', 'marierose123', 'MarieRose@gmail.com', 'Teacher', NULL, '$2y$10$HWx5Y9J7oU5W6shmn3UzzuCj05EFy16k24fb0WnIFh3cDSPAmR9jm', NULL, NULL, '', '', '', NULL, NULL, 4, NULL, 0, NULL, 0, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userfileserverfiles`
--

CREATE TABLE `userfileserverfiles` (
  `file_id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userfileserverfiles`
--

INSERT INTO `userfileserverfiles` (`file_id`, `folder_id`, `file_name`, `file_path`, `uploaded_at`, `userid`) VALUES
(1, 1, 'Form 14.jpg', 'uploads/Form 14.jpg', '2024-08-28 09:02:41', 0),
(2, 1, 'Account Settings.png', 'uploads/Account Settings.png', '2024-08-28 09:10:34', 0),
(3, 1, '1233333.png', 'uploads/1233333.png', '2024-08-28 09:11:13', 0),
(4, 1, '1233333.zip', 'uploads/1233333.zip', '2024-08-28 09:12:46', 0),
(5, 2, 'Form 14.jpg', 'uploads/Form 14.jpg', '2024-08-28 09:14:10', 0),
(6, 3, '1233333 (1).png', 'uploads/1233333 (1).png', '2024-08-28 09:52:37', 0),
(9, 13, '456724193_885042150151321_5238812809017422679_n.jpg', 'uploads/456724193_885042150151321_5238812809017422679_n.jpg', '2024-08-28 10:16:56', 0),
(13, 2, '1233333 (1).png', 'uploads/1233333 (1).png', '2024-08-28 11:29:26', 0),
(15, 27, 'Step 1 Implementation.txt', 'uploads/Step 1 Implementation.txt', '2024-08-28 13:13:25', 0),
(16, 14, '457273835_1196100201718595_6999637955955575012_n.jpg', 'C:\\xampp\\htdocs\\LanaoNationalHighschoolTeachersPortal\\Home/uploads/457273835_1196100201718595_6999637955955575012_n.jpg', '2024-08-29 11:49:37', 0),
(19, 13, 'grading_management (10).sql.gz', 'C:\\xampp\\htdocs\\LanaoNationalHighschoolTeachersPortal\\Home/uploads/grading_management (10).sql.gz', '2024-09-14 06:17:35', 10);

-- --------------------------------------------------------

--
-- Table structure for table `userfileserverfolders`
--

CREATE TABLE `userfileserverfolders` (
  `folder_id` int(11) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `folder_password` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userfileserverfolders`
--

INSERT INTO `userfileserverfolders` (`folder_id`, `folder_name`, `folder_password`, `userid`) VALUES
(1, 'Goods', '$2y$10$.xih6UQdMqRfD34H8aizqOAOxvGehuQ7C.cEmwWR5YZbogufoKOai', 0),
(2, '123', '$2y$10$GtBBd5sK8uKo4nCp4DaB4ejP7JOVtQS08MBn6rTpRG0vbO91UiFvC', 0),
(3, '321', '$2y$10$RMelRG50D8hIuPZYwvGu/.JWWVd1rFsAIF3IZUM0nuYRiMsOqC1yy', 0),
(4, '321', '$2y$10$GCJpzzxyvbQRDAm64ID7h.x3VPakIgQp0by4PGAlX9Cmi2SQG996W', 0),
(13, 'Antonio', '$2y$10$qVtfsJfguWIKtwiRqE0VGOI2LlD707b8856Ca1k99d/xVXN/myv4m', 10),
(14, 'Testing', '$2y$10$cnLK3WBVEDPJjwPRIxmNhux7Pyk5bb75EzmMY/Og9HNGIHvz4V6h2', 10),
(15, 'Degz', '$2y$10$9NszVMgM0.jyGzGsQfuIBuJ6TVNx4J96vLi.FHQooaaAcM8czBL6O', 8),
(16, '123', '$2y$10$1XRGH6BvvJTXdGyUF7bbeOc4ofR9DFIoaFR/mRS9JUByRwRNsSvO2', 12),
(19, '123', '$2y$10$tcENnGUeIgsrLEV0.oqOeOZKmNuF2GRLGUuzygKc3qGFw17P6xj5C', 8),
(21, '123', '$2y$10$MzHYF5VOkdKGHMPu6eHqReFzbdTZ7HzkWHuqMZ3DLwGuqYsDgBlru', 10),
(23, 'Delete', '$2y$10$FvXWgA.20gz.9kSgj9jXi.zZTLZpmfJ1VeM8Ly3N9kMmtD8AquWAe', 8),
(24, '123', '$2y$10$qE5iBpIHQqo/xMkLtRRPG.8tiYzY.kHGOK0zRbnfGaKuFkJNztbLW', 8),
(25, '123', '$2y$10$wHMGPZbJA1Ql6093k/pfX.r8fTTzKX1tjWHKoHl8Wvz7BEMX9gTYm', 12),
(26, 'SchoolWorks', '$2y$10$sjifcUo8WaqobHUSr0CoHex4esEgYZFvOtLHQIOYelgpet761MOBW', 93),
(27, 'SchoolWorksv2', '$2y$10$BXDPfrvEQGEpWSK25cUi8uLBu1kUgd59ANXBzLN9kPUBRkVGZV0ya', 93),
(28, 'Degoma\'s folder', '$2y$10$e.Azbb3XEBSu3jJ3aHx/DeukByGcs9Y52MbmUGNCcf2i8TfpPXBKG', 94),
(29, 'Userfolder', '$2y$10$c28THa1mHfIKGFhA5TtYUurd0B9HYZCAvzF0NFfKsCKJI/DO5sTZq', 12),
(30, 'sample tester', '$2y$10$nCvHttUetn69u6Gqvs8aNe0dgElJSPIXyZbOg2Y.r8AIbH7sLYYPe', 10),
(31, '123', '$2y$10$NF6qrcTxBQg9X20FWvT/6OHN1UrR2CVLYqtLIENTIMYx.BWAiGh/u', 104),
(32, 'ssssssssssssss', '$2y$10$nkwDeraZWmrANVCrgn566O49SFUEOHUHWaG3oFMwypplqQqpfQdUC', 104),
(34, 'Marie\'s documents', '$2y$10$2CxmUVHQna6YqYthrO330eb5y1zbd2moUHeAGAN0kf8E45Y6wWuYC', 131);

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity_log`
--

INSERT INTO `user_activity_log` (`id`, `username`, `action`, `timestamp`, `role`) VALUES
(1, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:04', NULL),
(2, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(3, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(4, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(5, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(6, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:06', NULL),
(7, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:09', NULL),
(8, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:11', NULL),
(9, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:13', NULL),
(10, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:15', NULL),
(11, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:22', NULL),
(12, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:08', NULL),
(13, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:11', NULL),
(14, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:28', NULL),
(15, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:31', NULL),
(16, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:36', NULL),
(17, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:52:13', NULL),
(18, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:26', NULL),
(19, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:30', NULL),
(20, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53', NULL),
(21, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53', NULL),
(22, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:55:26', NULL),
(23, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:57:59', NULL),
(24, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:18', NULL),
(25, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:34', NULL),
(26, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:20', NULL),
(27, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:44', NULL),
(28, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:05:33', NULL),
(29, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:08:58', NULL),
(30, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:09:03', NULL),
(31, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:18:02', NULL),
(32, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:16', NULL),
(33, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:23', NULL),
(34, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:33', NULL),
(35, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:23:55', NULL),
(36, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:37', NULL),
(37, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:39', NULL),
(38, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:42', NULL),
(39, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:44', NULL),
(40, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:59', NULL),
(41, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:26:05', NULL),
(42, 'admin', 'Accessed Admin Homepage', '2024-08-20 09:29:08', NULL),
(43, 'user1', 'Logged In', '2024-08-20 09:29:08', NULL),
(44, 'user2', 'Updated Profile', '2024-08-20 09:29:08', NULL),
(45, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:31:09', NULL),
(46, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13', NULL),
(47, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13', NULL),
(48, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:15', NULL),
(49, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:48', NULL),
(50, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:13', NULL),
(51, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:18', NULL),
(52, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(53, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(54, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(55, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:13', NULL),
(56, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:15', NULL),
(57, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:17', NULL),
(58, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(59, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(60, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(61, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:09', NULL),
(62, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:47', NULL),
(63, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:51', NULL),
(64, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:53', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encoded_learner_data`
--
ALTER TABLE `encoded_learner_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `learner_id` (`learner_id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `folder_id` (`folder_id`);

--
-- Indexes for table `fileserver_folders`
--
ALTER TABLE `fileserver_folders`
  ADD PRIMARY KEY (`folder_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `security_questions`
--
ALTER TABLE `security_questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `question` (`question`);

--
-- Indexes for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  ADD PRIMARY KEY (`form2Id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_subject` (`student_id`);

--
-- Indexes for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`),
  ADD KEY `fk_security_question` (`security_question`);

--
-- Indexes for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `fk_folder` (`folder_id`);

--
-- Indexes for table `userfileserverfolders`
--
ALTER TABLE `userfileserverfolders`
  ADD PRIMARY KEY (`folder_id`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `encoded_learner_data`
--
ALTER TABLE `encoded_learner_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1260;

--
-- AUTO_INCREMENT for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `fileserver_folders`
--
ALTER TABLE `fileserver_folders`
  MODIFY `folder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `security_questions`
--
ALTER TABLE `security_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  MODIFY `form2Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `userfileserverfolders`
--
ALTER TABLE `userfileserverfolders`
  MODIFY `folder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  ADD CONSTRAINT `admin_schedule_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `user` (`userid`) ON DELETE CASCADE;

--
-- Constraints for table `encoded_learner_data`
--
ALTER TABLE `encoded_learner_data`
  ADD CONSTRAINT `encoded_learner_data_ibfk_1` FOREIGN KEY (`learner_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  ADD CONSTRAINT `fileserver_files_ibfk_1` FOREIGN KEY (`folder_id`) REFERENCES `fileserver_folders` (`folder_id`) ON DELETE CASCADE;

--
-- Constraints for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `student_grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `fk_student_subject` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  ADD CONSTRAINT `teacher_assignments_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `user` (`userid`),
  ADD CONSTRAINT `teacher_assignments_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `teacher_assignments_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_security_question` FOREIGN KEY (`security_question`) REFERENCES `security_questions` (`id`);

--
-- Constraints for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  ADD CONSTRAINT `fk_folder` FOREIGN KEY (`folder_id`) REFERENCES `userfileserverfolders` (`folder_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `userfileserverfiles_ibfk_1` FOREIGN KEY (`folder_id`) REFERENCES `userfileserverfolders` (`folder_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
